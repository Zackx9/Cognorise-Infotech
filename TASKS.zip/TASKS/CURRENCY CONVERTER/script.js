

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currency Converter</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 400px; margin: auto; padding: 20px; }
        select, input { width: 100%; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Currency Converter</h1>
        <input type="number" id="amount" placeholder="Amount" />
        <select id="fromCurrency"></select>
        <select id="toCurrency"></select>
        <button id="convertBtn">Convert</button>
        <h2 id="result"></h2>
    </div>

    <script>
        const fromCurrency = document.getElementById('fromCurrency');
        const toCurrency = document.getElementById('toCurrency');
        const amount = document.getElementById('amount');
        const result = document.getElementById('result');
        const apiKey = 'c217cd199e938d7225f03e15'; // Replace with your API key
        const apiUrl = 'https://api.exchangerate-api.com/v4/latest/USD';

        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                const currencies = Object.keys(data.rates);
                currencies.forEach(currency => {
                    const option1 = document.createElement('option');
                    option1.value = currency;
                    option1.textContent = currency;
                    fromCurrency.appendChild(option1);

                    const option2 = document.createElement('option');
                    option2.value = currency;
                    option2.textContent = currency;
                    toCurrency.appendChild(option2);
                });
            });

        document.getElementById('convertBtn').addEventListener('click', () => {
            const from = fromCurrency.value;
            const to = toCurrency.value;
            const amountValue = amount.value;

            fetch(`https://api.exchangerate-api.com/v4/latest/${from}`)
                .then(response => response.json())
                .then(data => {
                    const rate = data.rates[to];
                    const convertedAmount = (amountValue * rate).toFixed(2);
                    result.textContent = `${amountValue} ${from} = ${convertedAmount} ${to}`;
                });
        });
    </script>
</body>
</html>
  </script>
</body>
</html>
